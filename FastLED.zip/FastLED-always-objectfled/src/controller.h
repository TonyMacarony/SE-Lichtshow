#ifndef __INC_CONTROLLER_H
#define __INC_CONTROLLER_H

/// @file controller.h
/// deprecated: base definitions used by led controllers for writing out led data

#include "cpixel_ledcontroller.h"

#endif
